package com.example.home_work_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
