import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

enum ImageSourceType { gallery, camera }
var photoList = [];

void main() {
  runApp(MaterialApp(
    home: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _MyAppState();
  }
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  File? _image;

  void getPhoto(BuildContext context, var type) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NewScreen_camera(type)),
    ).then((value) => setState(() {}));
  }

  // Tap to enter full screen image view
  void fullScreenImage(BuildContext context, var path) {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => FullScreenState(path)));
  }

  @override
  Widget build(BuildContext context) {
    Widget gridSection = GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
      ),
      itemCount: photoList.length,
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          onTap: () {
            fullScreenImage(context, photoList[index]);
          },
          child: Container(
            width: 200,
            height: 200,
            margin: EdgeInsets.only(),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.file(
                File(photoList[index]),
                fit: BoxFit.cover,
              ),
            ),
          ),
        );
      },
    );
    Widget buttonSection = Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        MaterialButton(
          color: Colors.blue,
          child: const Text(
            "Add from Gallery",
            style:
                TextStyle(color: Colors.white70, fontWeight: FontWeight.bold),
          ),
          onPressed: () {
            getPhoto(context, ImageSourceType.gallery);
          },
        ),
        MaterialButton(
          color: Colors.blue,
          child: const Text(
            "Add from Camera",
            style:
                TextStyle(color: Colors.white70, fontWeight: FontWeight.bold),
          ),
          onPressed: () {
            getPhoto(context, ImageSourceType.camera);
          },
        ),
      ],
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Album 561'),      ),
      body: Stack(
        children: [
          gridSection,
          Column(children: [const Spacer(), buttonSection])
        ],
      ),
    );
  }
}

// full screen image showing: two classes
class FullScreenState extends StatefulWidget {
  final path;
  FullScreenState(this.path);
  @override
  FullScreenImg createState() => FullScreenImg(this.path);
}

class FullScreenImg extends State<FullScreenState> {
  var path;
  var img;
  var width;
  var height;

  FullScreenImg(this.path);

  @override
  void initState() {
    super.initState();
    img = Image(image: FileImage(File(path)));
    // get image width and height
    img.image.resolve(ImageConfiguration()).addListener(
      ImageStreamListener(
        (ImageInfo info, bool _) {
          width = info.image.width;
          height = info.image.height;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Full screen image")),
        body: Stack(
          children: [
            Image.file(File(path)),
            Column(
              children: [
                const Spacer(),
                const Text("Image width:"),
                Text(width.toString()),
                const Text("Image height"),
                Text(height.toString())
              ],
            )
          ],
        ));
  }
}

class NewScreen_camera extends StatefulWidget {
  final type;
  NewScreen_camera(this.type);

  @override
  NewScreen_camera_state createState() => NewScreen_camera_state(this.type);
}

class NewScreen_camera_state extends State<NewScreen_camera> {
  var _image;
  var imagePicker;
  var type;

  NewScreen_camera_state(this.type);

  void initState() {
    super.initState();
    imagePicker = ImagePicker();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(type == ImageSourceType.camera
            ? 'Image from Camera'
            : 'Image from Gallery'),
      ),
      body: Column(children: <Widget>[
        const SizedBox(
          height: 52,
        ),
        Center(
          child: GestureDetector(
            onTap: () async {
              var source = type == ImageSourceType.camera
                  ? ImageSource.camera
                  : ImageSource.gallery;
              XFile image = await imagePicker.pickImage(source: source);

              Directory appDocumentsDirectory =
                  await getApplicationDocumentsDirectory();
              String prePath = appDocumentsDirectory.path;
              var rand = Random();
              String randomInt = rand.nextInt(99999999).toString();
              String newPath = "$prePath/$randomInt.jpg";
              File oldImage = File(image.path);
              final File newImgage = await oldImage.copy(newPath);

              setState(() {
                _image = newImgage;
                photoList.add(newImgage.path);
                // print(photoList);
              });
            },
            child: Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(color: Colors.red[200]),
                child: _image != null
                    ? Image.file(
                        _image,
                        width: 200,
                        height: 200,
                        fit: BoxFit.fitHeight,
                      )
                    : Container(
                        decoration: BoxDecoration(color: Colors.red[200]),
                        width: 200,
                        height: 200,
                        child: Icon(
                          Icons.camera_alt,
                          color: Colors.grey[800],
                        ),
                      ),),
          ),
        )
      ]),
    );
  }
}