#!/bin/bash

python3 7163312648_1190492356_4595082262_basic.py input.txt